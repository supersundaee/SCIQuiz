package com.mycompany.sciquiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
