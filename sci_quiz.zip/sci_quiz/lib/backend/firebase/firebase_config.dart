import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAuRxgo4-3AlKqsHvQNq42rRIXRyNBBeGw",
            authDomain: "sciquiz-a7e42.firebaseapp.com",
            projectId: "sciquiz-a7e42",
            storageBucket: "sciquiz-a7e42.appspot.com",
            messagingSenderId: "244436243940",
            appId: "1:244436243940:web:2b1b01decbf2bf59d063f1",
            measurementId: "G-5Z949CPQS9"));
  } else {
    await Firebase.initializeApp();
  }
}
