// Export pages
export '/pages/create_quiz_set/create_quiz_set_widget.dart'
    show CreateQuizSetWidget;
export '/pages/add_quiz/add_quiz_widget.dart' show AddQuizWidget;
export '/pages/authentication/authentication_widget.dart'
    show AuthenticationWidget;
export '/pages/quiz_page/quiz_page_widget.dart' show QuizPageWidget;
export '/pages/score_page/score_page_widget.dart' show ScorePageWidget;
export '/pages/homepagestudent/homepagestudent_widget.dart'
    show HomepagestudentWidget;
export '/pages/homepageteacher/homepageteacher_widget.dart'
    show HomepageteacherWidget;
export '/pages/user_manual_page/user_manual_page_widget.dart'
    show UserManualPageWidget;
export '/pages/home_admin/home_admin_widget.dart' show HomeAdminWidget;
export '/pages/user_settingadmin/user_settingadmin_widget.dart'
    show UserSettingadminWidget;
export '/pages/questionn/questionn_widget.dart' show QuestionnWidget;
export '/pages/editprofile/editprofile_widget.dart' show EditprofileWidget;
export '/pages/profilepage/profilepage_widget.dart' show ProfilepageWidget;
export '/forgotpasswordpage/forgotpasswordpage_widget.dart'
    show ForgotpasswordpageWidget;
